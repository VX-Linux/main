applet.currentConfigGroup = new Array("General");
applet.writeConfig("containmentType","Plasma");
applet.writeConfig("filterActivityInfo","false");
applet.writeConfig("filterByScreen","true");
applet.writeConfig("showIcon","false");
applet.reloadConfig();