### CHANGELOG

#### Version 0.2
* support only Plasma Desktop>=5.18

#### Version 0.1

* use Switch element for activating/disabling panel transparency
* hide when plasma widgets are locked

